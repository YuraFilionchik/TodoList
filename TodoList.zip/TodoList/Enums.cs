﻿namespace TodoList
{
    public enum PriorityType
    {
        Low,
        Medium,
        High
    }
}
